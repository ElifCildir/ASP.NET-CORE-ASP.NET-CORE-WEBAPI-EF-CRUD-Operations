﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ProjectEventAPI.Model;
using System.Linq;

namespace ProjectEventAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventController : ControllerBase
    {
        public readonly ApplicationDbContext application;

        public EventController(ApplicationDbContext application)
        {
            this.application = application;
        }


        [HttpGet]
        public IActionResult IndexE()
        {

            return Ok(application.Events.ToList());

        }

        [HttpGet("{id}")]
        public IActionResult IndexEId(int id)
        {
            return Ok(application.Events.Find(id));


        }

        [HttpPost]
        public IActionResult AddE(Event @event)

        {
            application.Add(@event);
            application.SaveChanges();
            return Created("", @event);



        }

        [HttpPut("{id}")]
        public IActionResult UpdateE(int id, Event @event)
        {

            var update = application.Events.FirstOrDefault(m => m.EventID == id);
            update.EventName = @event.EventName;
            update.EventDateTime = @event.EventDateTime;
            update.EventLocation = @event.EventLocation;
            update.EventOrganizer = @event.EventOrganizer;
            update.TeamID = @event.TeamID;

            application.SaveChanges();
            return NoContent();

        }


        [HttpDelete("{id}")]
        public IActionResult DeleteE(int id)
        {

            var delete = application.Events.FirstOrDefault(m => m.EventID == id);
            application.Remove(delete);
            application.SaveChanges();
            return NoContent();

        }





    }
}
