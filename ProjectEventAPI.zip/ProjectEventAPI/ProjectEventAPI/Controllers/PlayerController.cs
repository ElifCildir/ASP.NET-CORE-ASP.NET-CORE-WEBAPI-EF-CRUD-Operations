﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ProjectEventAPI.Model;
using System.Linq;
using static System.Net.Mime.MediaTypeNames;

namespace ProjectEventAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PlayerController : ControllerBase
          
    {

        public readonly ApplicationDbContext application;

        public PlayerController(ApplicationDbContext application)
        {
            this.application = application;
        }


        [HttpGet]
        public IActionResult IndexP()
        {

            return Ok(application.Players.ToList());

        }

        [HttpGet("{id}")]
        public IActionResult IndexPId(int id)
        {
            return Ok(application.Players.Find(id));


        }

        [HttpPost]
        public IActionResult AddT(Player player)

        {
            application.Add(player);
            application.SaveChanges();
            return Created("", player);



        }

        [HttpPut("{id}")]
        public IActionResult UpdateP(int id, Player player)
        {

            var update = application.Players.FirstOrDefault(m => m.PlayerID == id);
            update.PlayerNameSurname = player.PlayerNameSurname;
            update.PlayerDOB = player.PlayerDOB;
            update.PlayerCountry = player.PlayerCountry;
            update.TeamID = player.TeamID;

            application.SaveChanges();
            return NoContent();

        }


        [HttpDelete("{id}")]
        public IActionResult DeleteP(int id)
        {

            var delete = application.Players.FirstOrDefault(m => m.PlayerID == id);
            application.Remove(delete);
            application.SaveChanges();
            return NoContent();

        }






    }
}
