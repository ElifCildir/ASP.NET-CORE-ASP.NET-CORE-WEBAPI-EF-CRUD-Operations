﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ProjectEventAPI.Model;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Transactions;

namespace ProjectEventAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TeamController : ControllerBase
    {
        public readonly ApplicationDbContext application;

        public TeamController(ApplicationDbContext application)
        {
            this.application = application;
        }


        [HttpGet]
        public IActionResult IndexT()
        {

            return Ok(application.Teams.ToList());

        }

        [HttpGet("{id}")]
        public IActionResult IndexTId(int id)
        {
            return Ok(application.Teams.Find(id));
        
        
        }

        [HttpPost]
        public IActionResult AddT(Team team)

        {
            application.Add(team);
            application.SaveChanges();
            return Created("", team);

        
        
        }

        [HttpPut("{id}")]
        public IActionResult UpdateT(int id, Team team)
        {

            var update = application.Teams.FirstOrDefault(m => m.TeamID == id);
            update.TeamName = team.TeamName;
            update.TeamLogo= team.TeamLogo;
            update.TeamNumberofMember = team.TeamNumberofMember;
            update.YearFounded= team.YearFounded;
            update.CoachId= team.CoachId;
       
            application.SaveChanges();
            return NoContent();

        }


        [HttpDelete("{id}")]
        public IActionResult DeleteT(int id)
        {

            var delete = application.Teams.FirstOrDefault(m => m.TeamID == id);
            application.Remove(delete);
            application.SaveChanges();
            return NoContent();

        }




    }
}
