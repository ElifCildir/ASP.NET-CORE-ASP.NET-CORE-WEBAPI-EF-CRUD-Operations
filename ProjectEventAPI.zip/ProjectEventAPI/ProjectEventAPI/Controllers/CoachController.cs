﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ProjectEventAPI.Model;
using System.Linq;

namespace ProjectEventAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CoachController : ControllerBase
    {
        public readonly ApplicationDbContext application;

        public CoachController(ApplicationDbContext application)
        {
            this.application = application;
        }


        [HttpGet]
        public IActionResult IndexC()
        {
            return Ok(application.Coaches.ToList());


        }

        [HttpGet("{id}")]
        public IActionResult IndexCId(int id)
        {

            return Ok(application.Coaches.FirstOrDefault(m=>m.CoachID==id));



        }

        [HttpPost]
        public IActionResult AddC(Coach coach)
        {
            application.Add(coach);
            application.SaveChanges();
            return Created("", coach);


        }


        [HttpPut("{id}")]
        public IActionResult UpdateC(int id,Coach coach)
        {
            var update = application.Coaches.Find(id);
            update.CoachNameSurname=coach.CoachNameSurname;
            update.CoachCountry=coach.CoachCountry;
            update.CoachStartDate=coach.CoachStartDate;
            application.SaveChanges();
            return NoContent();


        }

    

        [HttpDelete ("{id}")]
        public IActionResult DeleteC(int id) 
        { 

            var delete= application.Coaches.FirstOrDefault(m=>m.CoachID==id);
            application.Remove(delete);
            application.SaveChanges ();
            return NoContent();
        
        }




    }
}
